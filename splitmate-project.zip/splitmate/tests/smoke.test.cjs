const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const match = html.match(/<script>([\s\S]*?)<\/script>/);
assert(match, 'main app script exists');
const elements = new Map();
function element(id) {
  if (!elements.has(id)) elements.set(id, {
    id, innerHTML: '', textContent: '', value: '', dataset: {},
    classList: { add() {}, remove() {}, toggle() {} },
    addEventListener() {}, scrollIntoView() {}, focus() {}, setSelectionRange() {}
  });
  return elements.get(id);
}
const document = {
  getElementById: element,
  querySelectorAll() { return []; },
  querySelector() { return null; },
  addEventListener() {},
  createElement() { return { click() {}, set href(v) {}, set download(v) {} }; }
};
const localStorage = { getItem() { return null; }, setItem() {} };
const window = { addEventListener() {}, location: { href: '' }, devicePixelRatio: 1 };
const context = {
  document, localStorage, window, navigator: {}, console, Intl, Date, Math,
  Number, String, Object, Array, Set, Map, JSON,
  Blob: function Blob() {}, URL: { createObjectURL() { return ''; }, revokeObjectURL() {} },
  FileReader: function FileReader() {}, confirm() { return true; },
  requestAnimationFrame(fn) { fn(); }, setTimeout, clearTimeout
};
vm.createContext(context);
vm.runInContext(match[1] + '\n;globalThis.__test={netBalances,settlePlan,totalOwed,totalOwe,render};', context);
const app = context.__test;

const balances = app.netBalances('g-flat');
assert(Math.abs(balances.You - 750) < 0.01);
assert(Math.abs(balances.Aisha + 1050) < 0.01);
assert(Math.abs(balances.Rohan - 1350) < 0.01);
assert(Math.abs(balances.Neha + 1050) < 0.01);
assert(Math.abs(Object.values(balances).reduce((sum, value) => sum + value, 0)) < 0.01, 'group balances sum to zero');

const plan = app.settlePlan('g-flat');
assert.strictEqual(plan.length, 3, 'demo group can be cleared in three transfers');
for (const name of Object.keys(balances)) {
  const pays = plan.filter(p => p.from === name).reduce((sum, p) => sum + p.amount, 0);
  const receives = plan.filter(p => p.to === name).reduce((sum, p) => sum + p.amount, 0);
  assert(Math.abs(balances[name] + pays - receives) < 0.01, `repayment plan clears ${name}`);
}
assert(app.totalOwed() > 0 && app.totalOwe() === 0, 'dashboard totals calculate');
assert(element('main').innerHTML.includes('Your groups'), 'dashboard renders at startup');
console.log('SplitMate smoke tests passed: balance math, debt simplification and initial render.');
